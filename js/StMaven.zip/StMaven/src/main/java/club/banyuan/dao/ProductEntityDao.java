package club.banyuan.dao;

import club.banyuan.pojo.ProductEntity;

import java.util.List;

public interface ProductEntityDao {
    public List<ProductEntity> getAll();
}
